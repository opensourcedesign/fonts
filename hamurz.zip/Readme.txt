Thanks for downloading this file.

If you want the premium version please visit this link http://crtv.mk/b0Rgi

Premium version specification :
- Lowercase
- Uppercase
- Numeral & Punctuation
- 3 Styles font : clean, rough & vintage look

Opentype features ready with Stylistic Set, Contextual alternates. With Opentype features you can applied to logos, product, display, clothing, quotes and many more. You can applied to all typography with mix and match pairs of letters to fit your own designs.

To access the alternate glyphs, you need a program that supports OpenType features such as Adobe Photoshop CC, Adobe Illustrator CS/CC and Adobe Indesign.

Thanks
Bagus Budiyanto
https://creativemarket.com/angkalimabelas
http://angkalimabelas.net/